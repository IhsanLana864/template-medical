<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Medilix - Healthcare & Medical Bootstrap HTML5 Template</title>
    <meta name="description" content="Medilix - Healthcare & Medical Bootstrap HTML5 Template">
    <meta name="author" content="ahmmedsabbirbd">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/favicon.svg">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/fontawesome-pro.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer-theme-default.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body class="body-4">

<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
<![endif]-->

<!-- preloader start -->
<div id="preloader" class="preloader__4">
    <div class="preloader-close preloader-close__4">x</div>
    <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1 home-4"></div>
        <div class="sk-child sk-bounce2 home-4"></div>
        <div class="sk-child sk-bounce3 home-4"></div>
    </div>
</div>
<!-- preloader end -->

<!-- preloader start -->
<div class="loading-form">
    <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
    </div>
</div>
<!-- preloader end -->

<!-- Backtotop start -->
<div id="scroll-percentage">
    <span id="scroll-percentage-value" data-default-color="var(--rr-color-900)" data-scroll-color="var(--rr-theme-glow)"></span>
</div>
<!-- Backtotop end -->

<!-- Offcanvas area start -->
<div class="fix">
    <div class="offcanvas__area offcanvas__area__4">
        <div class="offcanvas__wrapper">
            <div class="offcanvas__content">
                <div class="offcanvas__top d-flex justify-content-between align-items-center">
                    <div class="offcanvas__logo">
                        <a href="index.html">
                            <img src="assets/imgs/logo/logo-white-4.svg" alt="logo not found">
                        </a>
                    </div>
                    <div class="offcanvas__close">
                        <button class="offcanvas-close-icon animation--flip">
                                <span class="offcanvas-m-lines">
                            <span class="offcanvas-m-line line--1"></span><span class="offcanvas-m-line line--2"></span><span class="offcanvas-m-line line--3"></span>
                                </span>
                        </button>
                    </div>
                </div>
                <div class="mobile-menu fix"></div>
                <div class="offcanvas__social">
                    <h4 class="offcanvas__title mb-20">Subscribe & Follow</h4>
                    <p class="mb-30">Medical practices evolved over millennia, from ancient civilizations like Egypt and Mesopotamia to the groundbreaking</p>
                    <ul class="header-top-socail-menu d-flex">
                        <li><a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="https://twitter.com/"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https://www.pinterest.com/"><i class="fa-brands fa-pinterest-p"></i></a></li>
                        <li><a href="https://vimeo.com/"><i class="fa-brands fa-vimeo-v"></i></a></li>
                    </ul>
                </div>
                <div class="offcanvas__btn d-sm-none">
                    <div class="header__btn-wrap">
                        <a href="https://themeforest.net/user/rrdevs/portfolio" class="rr-btn rr-btn__theme rr-btn__theme-white mt-40 mt-sm-35 mt-xs-30">
                            <span class="btn-wrap">
                                <span class="text-one">Purchase Now</span>
                                <span class="text-two">Purchase Now</span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="offcanvas__overlay"></div>
<div class="offcanvas__overlay-white"></div>
<!-- Offcanvas area start -->

<!-- Header area start -->
<header>
    <div id="header-sticky" class="header__area header-5">
        <div class="container">
            <div class="mega__menu-wrapper p-relative">
                <div class="header__main">
                    <div class="header__logo">
                        <a href="index.html">
                            <div class="logo">
                                <img src="assets/imgs/logo/logo-4.svg" alt="logo not found">
                            </div>
                        </a>
                    </div>

                    <div class="mean__menu-wrapper d-none d-lg-block">
                        <div class="main-menu main-menu-5">
                            <nav id="mobile-menu">
                                <ul>
                                    <li class="has-dropdown has-mega-menu active">
                                        <a href="javascript:void(0)">Home</a>
                                        <ul class="mega-menu mega-menu-grid-3">
                                            <li>
                                                <div class="home__menu-item">
                                                    <div class="home__menu-thumb">
                                                        <img src="assets/imgs/menu/menu-home-1.jpg" alt="thumb not found">
                                                        <div class="home__menu-buttons">
                                                            <a href="index.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                            <a href="index-one-page.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <h4 class="home__menu-title">Eye Care</h4>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="home__menu-item">
                                                    <div class="home__menu-thumb">
                                                        <img src="assets/imgs/menu/menu-home-2.jpg" alt="thumb not found">
                                                        <div class="home__menu-buttons">
                                                            <a href="index-2.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                            <a href="index-2-one-page.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <h4 class="home__menu-title">Dental Care</h4>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="home__menu-item">
                                                    <div class="home__menu-thumb">
                                                        <img src="assets/imgs/menu/menu-home-3.jpg" alt="thumb not found">
                                                        <div class="home__menu-buttons">
                                                            <a href="index-3.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                            <a href="index-3-one-page.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <h4 class="home__menu-title">Medical Care</h4>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="home__menu-item">
                                                    <div class="home__menu-thumb">
                                                        <img src="assets/imgs/menu/menu-home-4.jpg" alt="thumb not found">
                                                        <div class="home__menu-buttons">
                                                            <a href="index-4.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                            <a href="index-4-one-page.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <h4 class="home__menu-title">Psycology & Counseling</h4>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="home__menu-item">
                                                    <div class="home__menu-thumb">
                                                        <img src="assets/imgs/menu/menu-home-5.jpg" alt="thumb not found">
                                                        <div class="home__menu-buttons">
                                                            <a href="index-5.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">MULTI PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                            <a href="index-5-one-page.html" class="rr-btn">
                                                                <span class="btn-wrap">
                                                                    <span class="text-one">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                    <span class="text-two">ONE PAGE <i class="fa-solid fa-plus"></i></span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <h4 class="home__menu-title">Skin Care</h4>
                                            </div>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="has-dropdown ">
                                        <a href="javascript:void(0)">Pages</a>
                                        <ul class="submenu">
                                            <li><a href="faq.html">Faq</a></li>
                                            <li><a href="about-us.html">About us</a></li>
                                            <li><a href="pricing.html">Pricing</a></li>
                                            <li><a href="pricing-2.html">Pricing 2</a></li>
                                            <li><a href="404.html">404 Page</a></li>
                                            <li><a href="appoinment.html">Appointment</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-dropdown">
                                        <a href="service.html">Services</a>
                                        <ul class="submenu">
                                            <li><a href="service.html">Service</a></li>
                                            <li><a href="service-2.html">Service 2</a></li>
                                            <li><a href="service-details.html">Services Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-dropdown">
                                        <a href="doctor.html">Doctor</a>
                                        <ul class="submenu">
                                            <li><a href="doctor.html">Doctor</a></li>
                                            <li><a href="doctor-2.html">Doctor 2</a></li>
                                            <li><a href="doctor-details.html">Doctor Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-dropdown">
                                        <a href="portfolio.html">Portfolio</a>
                                        <ul class="submenu">
                                            <li><a href="portfolio.html">Portfolio</a></li>
                                            <li><a href="portfolio-2.html">Portfolio 2</a></li>
                                            <li><a href="portfolio-details.html">Portfolio Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-dropdown">
                                        <a href="blog.html">Blog</a>
                                        <ul class="submenu">
                                            <li><a href="blog.html">Blog</a></li>
                                            <li><a href="blog-grid.html">Blog Grid</a></li>
                                            <li><a href="blog-grid-2.html">Blog Grid 2</a></li>
                                            <li><a href="blog-details.html">Blog Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact.html">contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <div class="header__right">
                        <div class="header__action d-flex align-items-center">
                            <div class="header__btn-wrap d-none d-sm-inline-flex">
                                <a href="contact.html" class="rr-btn rr-btn__border">
                                    <span class="btn-wrap">
                                        <span class="text-one">Free Consultation<i class="fa-solid fa-circle-plus"></i></span>
                                        <span class="text-two">Free Consultation<i class="fa-solid fa-circle-plus"></i></span>
                                    </span>
                                </a>
                            </div>

                            <div class="header__hamburger ml-20 d-xl-none">
                                <div class="sidebar__toggle">
                                    <a class="bar-icon" href="javascript:void(0)">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Header area end -->

<!-- Body main wrapper start -->
<main>

    <section class="banner-4">
        <div class="banner-4__c">
        <div class="container">
            <div class="banner-4__bg-c">
                <div class="banner-4__bg-left-top"></div>
                <div class="banner-4__bg-left-bottom"></div>
            </div>

            <div class="banner-4__bg-c-2">
                <div class="banner-4__bg-right-top"></div>
                <div class="banner-4__bg-right-bottom"></div>

            </div>
            <div class="row">
                <div class="col-lg-7 col-xl-6">
                    <div class="banner-4__content">
                        <h5 class="banner-4__subtitle title-glow mb-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Find Balance</h5>
                        <h1 class="banner-4__title color-theme-black mb-20 title-animation">Empowering Minds Healing Hearts</h1>
                        <p class="mb-0">By creating a safe and non-judgmental space, they empower individuals to explore their inner experiences</p>

                        <div class="banner-4__btn-box mt-40">
                            <a href="#" class="rr-btn rr-btn__border">
                                <span class="btn-wrap">
                                    <span class="text-one">Free Consultation<i class="fa-solid fa-circle-plus"></i></span>
                                    <span class="text-two">Free Consultation<i class="fa-solid fa-circle-plus"></i></span>
                                </span>
                            </a>

                            <div class="banner-4__btn-box-wrapper">
                                <a href="https://www.youtube.com/watch?v=dyNpojnbNT4" class="popup-video" data-effect="mfp-move-from-top vertical-middle">
                                    <div class="icon zooming">
                                        <svg width="14" height="18" viewBox="0 0 14 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0 0V17.5L13.75 8.75L0 0Z" fill="white"/>
                                        </svg>
                                    </div>
                                    <span>Watch more</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5 col-xl-6">
                    <div class="banner-4__media">
                        <div class="banner-4__thumb wow clip-a-z">
                            <img src="./assets/imgs/banner-4/banner-4.png" class="img-fluid" alt="image not found">
                        </div>

                        <div class="banner-4__box">
                            <div class="circle">
                                <div class="logo">
                                    <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M23.9734 30.3114H1.17422C1.06611 30.3114 0.962431 30.2691 0.885989 30.1939C0.809546 30.1187 0.766602 30.0167 0.766602 29.9103V7.4302C0.766602 7.32381 0.809546 7.22177 0.885989 7.14654C0.962431 7.07132 1.06611 7.02905 1.17422 7.02905H23.9734C24.0815 7.02905 24.1852 7.07132 24.2616 7.14654C24.3381 7.22177 24.381 7.32381 24.381 7.4302V29.9103C24.381 30.0167 24.3381 30.1187 24.2616 30.1939C24.1852 30.2691 24.0815 30.3114 23.9734 30.3114ZM1.58183 29.5091H23.5658V7.82866H1.58183V29.5091Z" fill="#169091"/>
                                        <path d="M30.371 23.606H7.5718C7.4637 23.606 7.36002 23.5638 7.28358 23.4885C7.20713 23.4133 7.16419 23.3113 7.16419 23.2049V15.4682C7.16419 15.3618 7.20713 15.2597 7.28358 15.1845C7.36002 15.1093 7.4637 15.067 7.5718 15.067H13.3762C13.4843 15.067 13.588 15.1093 13.6644 15.1845C13.7409 15.2597 13.7838 15.3618 13.7838 15.4682C13.7838 15.5746 13.7409 15.6766 13.6644 15.7518C13.588 15.827 13.4843 15.8693 13.3762 15.8693H7.97942V22.8037H29.9525V1.11259H7.96855V7.42926C7.96855 7.53565 7.9256 7.63768 7.84916 7.71291C7.77272 7.78814 7.66904 7.8304 7.56093 7.8304C7.45283 7.8304 7.34915 7.78814 7.27271 7.71291C7.19626 7.63768 7.15332 7.53565 7.15332 7.42926V0.711446C7.15332 0.605056 7.19626 0.503023 7.27271 0.427795C7.34915 0.352566 7.45283 0.310303 7.56093 0.310303H30.3601C30.4682 0.310303 30.5719 0.352566 30.6484 0.427795C30.7248 0.503023 30.7677 0.605056 30.7677 0.711446V23.1942C30.7699 23.3004 30.7295 23.4032 30.6553 23.4803C30.581 23.5573 30.4789 23.6025 30.371 23.606Z" fill="#169091"/>
                                        <path d="M16.1292 16.739C15.8733 16.7396 15.6229 16.6654 15.4099 16.5258C15.1968 16.3862 15.0306 16.1876 14.9323 15.9551C14.8339 15.7225 14.8079 15.4665 14.8575 15.2194C14.9071 14.9723 15.0301 14.7452 15.2109 14.5669C15.3917 14.3886 15.6222 14.2671 15.8732 14.2178C16.1241 14.1684 16.3844 14.1935 16.6209 14.2898C16.8574 14.386 17.0596 14.5492 17.2018 14.7586C17.3441 14.968 17.42 15.2142 17.42 15.4661C17.42 15.8032 17.2841 16.1266 17.0421 16.3652C16.8001 16.6039 16.4718 16.7383 16.1292 16.739ZM16.1292 14.9981C16.0344 14.9975 15.9416 15.0248 15.8625 15.0763C15.7834 15.1278 15.7217 15.2013 15.6852 15.2874C15.6486 15.3735 15.6389 15.4684 15.6573 15.5599C15.6757 15.6515 15.7213 15.7356 15.7883 15.8016C15.8554 15.8675 15.9408 15.9124 16.0339 15.9305C16.1269 15.9486 16.2233 15.939 16.3108 15.9031C16.3983 15.8671 16.473 15.8064 16.5253 15.7286C16.5776 15.6508 16.6053 15.5594 16.6048 15.4661C16.6041 15.3422 16.5537 15.2235 16.4647 15.1359C16.3757 15.0483 16.2551 14.9988 16.1292 14.9981Z" fill="#169091"/>
                                    </svg>
                                </div>
                                <div class="text">
                                    <p>
                                        Best SWorking Since 2024
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="banner-4__bottom-text">
                    <h2>Mind Matters</h2>
                </div>
            </div>
        </div>
    </div>
    </section>

    <section class="psychology psychology__top-space">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-4">
                    <div class="psychology__item">
                        <div class="psychology__wrapper">
                            <img src="./assets/imgs/psychology/psychology-1.svg" alt="image not found">
                            <h4>Tranquil Counseling</h4>
                        </div>
                        <p class="mb-0">Psychology and counseling are critical fields that help individuals understand </p>

                        <div class="psychology__socail">
                            <a href="https://www.instagram.com/"><i class="fa-brands fa-instagram"></i></a>
                            <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/">
                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.0596 6.77295L15.8879 -0.00195312H14.5068L9.44607 5.8806L5.40411 -0.00195312H0.742188L6.85442 8.89352L0.742188 15.998H2.12338L7.4676 9.78587L11.7362 15.998H16.3981L10.0593 6.77295H10.0596ZM8.16787 8.97189L7.54857 8.0861L2.62104 1.03779H4.74248L8.71905 6.726L9.33834 7.61179L14.5074 15.0056H12.386L8.16787 8.97223V8.97189Z" fill="#071C3C"/>
                                </svg>
                            </a>
                            <a href="https://www.linkedin.com/"><i class="fa-brands fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-xl-4">
                    <div class="psychology__item">
                        <div class="psychology__wrapper">
                            <img src="./assets/imgs/psychology/psychology-2.svg" alt="image not found">
                            <h4>Empowerment Therapy</h4>
                        </div>
                        <p class="mb-0">Counseling are critical fields that help individuals understand and manage</p>

                        <div class="psychology-wrapper">
                            <i class="fa-solid fa-phone"></i>
                            <div class="psychology-wrapper-text">
                                <span>Call Us:</span>
                                <h5><a href="tel:15550133">(+1) 555-0133</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="psychology__item">
                        <div class="psychology__wrapper">
                            <img src="./assets/imgs/psychology/psychology-3.svg" alt="image not found">
                            <h4>Compassionate Care</h4>
                        </div>
                        <p class="mb-0">Counseling are critical fields that help individuals understand and manage</p>

                        <div class="psychology__location">
                            <i class="fa-solid fa-location-dot"></i>
                            <h5><a href="https://maps.app.goo.gl/4XYAPDmpesGnSbsC8">3891 Ranchview Dr. Richardson, California 62639</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-us-6 section-space__top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-us-6__media">
                        <div class="about-us-6__shape">
                            <img src="./assets/imgs/about-us-6/shape.png" alt="image not found">
                        </div>
                        <img class="wow clip-a-z" src="./assets/imgs/about-us-6/about-1.jpg" alt="image not found">
                        <div class="about-us-6__small-box upDown">
                            <div class="about-us-6__small-box__icon">
                                <img src="./assets/imgs/about-us-6/daily-activity.svg" alt="image not found">
                            </div>
                            <div class="about-us-6__small-box__text">
                                <h5>Daily Activity</h5>
                                <p class="mb-0">Loream is ispam</p>
                            </div>
                        </div>
                        <div class="about-us-6__awarded-box downUp">
                            <img src="./assets/imgs/about-us-6/awarded.svg" alt="image not found">
                            <h4>Best Awarded Company</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-us-6__content">
                        <div class="section__title-wrapper mb-40">
                            <h5 class="section__subtitle title-glow mb-10 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> About Us</h5>
                            <h2 class="section__title color-theme-black font-medium mb-15 title-animation">Personalized Care for Personal Growth</h2>
                            <p class="mb-0">Et purus duis sollicitudin dignissim habitant. Egestas nulla quis venenatis cras sed eu massa loren ipsum dummy text provide</p>
                        </div>

                        <div class="about-us-6__wrapper">
                            <div class="about-us-6__item">
                                <div class="about-us-6__item-icon">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                                <div class="about-us-6__item-text">
                                    <h4>Mindful Pathways Counseling</h4>
                                    <p class="mb-0">Ultimately, psychology and counseling play a vital role in helping people lead more fulfilling and balanced lives</p>
                                </div>
                            </div>

                            <div class="about-us-6__item">
                                <div class="about-us-6__item-icon">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                                <div class="about-us-6__item-text">
                                    <h4>Harmony Mental Health Services</h4>
                                    <p class="mb-0">Ultimately, psychology and counseling play a vital role in helping people lead more fulfilling and balanced lives</p>
                                </div>
                            </div>
                        </div>
                        <a href="about-us.html" class="rr-btn rr-btn__border">
                            <span class="btn-wrap">
                                <span class="text-one">Read More <i class="fa-solid fa-circle-plus"></i></span>
                                <span class="text-two">Read More <i class="fa-solid fa-circle-plus"></i></span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- latest-services-2 area start -->
    <section class="latest-services-2 section-space__top ">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section__title-wrapper mb-60 mb-30">
                        <h5 class="section__subtitle title-glow mb-15 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Latest Services</h5>
                        <h2 class="section__title color-theme-black font-medium mb-10 title-animation">Transforming Lives One Session at a Time</h2>
                    </div>
                </div>
            </div>

            <div class="row mb-minus-30">
                <div class="col-xl-6">
                    <div class="latest-services-2__item">
                        <div class="latest-services-2__media wow clip-a-z">
                            <img src="./assets/imgs/latest-services-2/latest-services-1.jpg" alt="image not foun">
                        </div>

                        <div class="latest-services-2__content">
                            <div class="latest-services-2__wrapper">
                                <img src="./assets/imgs/latest-services-2/services-1.png" alt="image not found">
                                <h4><a href="service-details.html">Radiant Mind</a></h4>
                            </div>

                            <p class="mb-0">These disciplines focus on improving mental health and well-being by proThese disciplines focus on improving mental health</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="latest-services-2__item">
                        <div class="latest-services-2__media wow clip-a-z">
                            <img src="./assets/imgs/latest-services-2/latest-services-2.jpg" alt="image not foun">
                        </div>

                        <div class="latest-services-2__content">
                            <div class="latest-services-2__wrapper">
                                <img src="./assets/imgs/latest-services-2/services-2.png" alt="image not found">
                                <h4><a href="service-details.html">Resilience Therapy</a></h4>
                            </div>

                            <p class="mb-0">These disciplines focus on improving mental health and well-being by proThese disciplines focus on improving mental health</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="latest-services-2__item">
                        <div class="latest-services-2__media wow clip-a-z">
                            <img src="./assets/imgs/latest-services-2/latest-services-3.jpg" alt="image not foun">
                        </div>

                        <div class="latest-services-2__content">
                            <div class="latest-services-2__wrapper">
                                <img src="./assets/imgs/latest-services-2/services-3.png" alt="image not found">
                                <h4><a href="service-details.html">Balanced Life</a></h4>
                            </div>

                            <p class="mb-0">These disciplines focus on improving mental health and well-being by proThese disciplines focus on improving mental health</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="latest-services-2__item">
                        <div class="latest-services-2__media wow clip-a-z">
                            <img src="./assets/imgs/latest-services-2/latest-services-4.jpg" alt="image not foun">
                        </div>

                        <div class="latest-services-2__content">
                            <div class="latest-services-2__wrapper">
                                <img src="./assets/imgs/latest-services-2/services-4.png" alt="image not found">
                                <h4><a href="service-details.html">Clarity Mental</a></h4>
                            </div>

                            <p class="mb-0">These disciplines focus on improving mental health and well-being by proThese disciplines focus on improving mental health</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- latest-services-2 area end -->

    <!-- our-portfolio-2 area start -->
    <section class="our-portfolio-2 section-space__top">
        <div class="container">
            <div class="row mb-60 mb-xs-50 justify-content-center align-items-center">
                <div class="col-lg-6">
                    <div class="section__title-wrapper mb-md-30 mb-sm-30 mb-xs-20">
                        <h5 class="section__subtitle title-glow mb-15 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Our Portfolio</h5>
                        <h2 class="section__title color-theme-black mb-0 title-animation">A Safe Space for Growth and Healing</h2>
                    </div>
                </div>
                <div class="col-lg-6 d-flex justify-content-lg-end">
                    <a href="portfolio-details.html" class="rr-btn">
                        <span class="btn-wrap">
                            <span class="text-one">View More <i class="fa-solid fa-circle-plus"></i></span>
                            <span class="text-two">View More <i class="fa-solid fa-circle-plus"></i></span>
                        </span>
                    </a>
                </div>
            </div>
            <div class="swiper our-portfolio-2__active">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="our-portfolio-2__item position-relative overflow-hidden">
                            <div class="our-portfolio-2__item__content">
                                <a href="portfolio-details.html" class="our-portfolio-2__item__content-media ">
                                    <img src="./assets/imgs/our-portfolio-2/our-portfolio-1.jpg" class="img-fluid wow clip-a-z" alt="">
                                </a>
                                <div class="our-portfolio-2__item__wrapper">
                                    <div class="our-portfolio-2__item__text">
                                        <p>Reclaim Your Life</p>
                                        <h4 class="title-animation"><a href="portfolio-details.html">Discover Your True</a></h4>
                                    </div>
                                    <div class="our-portfolio-2__item__icon">
                                        <a href="portfolio-details.html"><i class="fa-solid fa-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="our-portfolio-2__item position-relative overflow-hidden">
                            <div class="our-portfolio-2__item__content">
                                <a href="portfolio-details.html" class="our-portfolio-2__item__content-media ">
                                    <img src="./assets/imgs/our-portfolio-2/our-portfolio-2.jpg" class="img-fluid wow clip-a-z" alt="">
                                </a>
                                <div class="our-portfolio-2__item__wrapper">
                                    <div class="our-portfolio-2__item__text">
                                        <p>Reclaim Your Life</p>
                                        <h4 class="title-animation"><a href="portfolio-details.html">Catalyst Services</a></h4>
                                    </div>
                                    <div class="our-portfolio-2__item__icon">
                                        <a href="portfolio-details.html"><i class="fa-solid fa-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="our-portfolio-2__item position-relative overflow-hidden">
                            <div class="our-portfolio-2__item__content">
                                <a href="portfolio-details.html" class="our-portfolio-2__item__content-media ">
                                    <img src="./assets/imgs/our-portfolio-2/our-portfolio-3.jpg" class="img-fluid wow clip-a-z" alt="">
                                </a>
                                <div class="our-portfolio-2__item__wrapper">
                                    <div class="our-portfolio-2__item__text">
                                        <p>Reclaim Your Life</p>
                                        <h4 class="title-animation"><a href="portfolio-details.html">Wave Solutions</a></h4>
                                    </div>
                                    <div class="our-portfolio-2__item__icon">
                                        <a href="portfolio-details.html"><i class="fa-solid fa-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="our-portfolio-2__item position-relative overflow-hidden">
                            <div class="our-portfolio-2__item__content">
                                <a href="portfolio-details.html" class="our-portfolio-2__item__content-media ">
                                    <img src="./assets/imgs/our-portfolio-2/our-portfolio-4.jpg" class="img-fluid wow clip-a-z" alt="">
                                </a>
                                <div class="our-portfolio-2__item__wrapper">
                                    <div class="our-portfolio-2__item__text">
                                        <p>Reclaim Your Life</p>
                                        <h4 class="title-animation"><a href="portfolio-details.html">Health Hub</a></h4>
                                    </div>
                                    <div class="our-portfolio-2__item__icon">
                                        <a href="portfolio-details.html"><i class="fa-solid fa-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="our-portfolio-2__item position-relative overflow-hidden">
                            <div class="our-portfolio-2__item__content">
                                <a href="portfolio-details.html" class="our-portfolio-2__item__content-media ">
                                    <img src="./assets/imgs/our-portfolio-2/our-portfolio-5.jpg" class="img-fluid wow clip-a-z" alt="">
                                </a>
                                <div class="our-portfolio-2__item__wrapper">
                                    <div class="our-portfolio-2__item__text">
                                        <p>Reclaim Your Life</p>
                                        <h4 class="title-animation"><a href="portfolio-details.html">Weave Solutions</a></h4>
                                    </div>
                                    <div class="our-portfolio-2__item__icon">
                                        <a href="portfolio-details.html"><i class="fa-solid fa-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="our-portfolio-2__scrollbar mt-80 mt-sm-60 mt-xs-45"></div>
            </div>
        </div>
    </section>
    <!-- our-portfolio-2 area end -->

    <!-- cta-3 area start -->
    <section class="cta-3 cta-3__space-top">
        <div class="container">
            <div class="cta-3__wrapper">
                <div class="cta-3__shape">
                    <img src="./assets/imgs/cta-3/cta-shape.png" alt="image not found">
                </div>
                <div class="cta-3__media wow clip-a-z">
                    <img src="./assets/imgs/cta-3/cta.png" alt="image not found">
                </div>

                <div class="cta-3__content">
                    <h2 class="h1 title-animation">Your Journey to Mental Wellness Begins Here</h2>

                    <a href="contact.html" class="rr-btn">
                        <span class="btn-wrap">
                            <span class="text-one">Contact Us <i class="fa-solid fa-circle-plus"></i></span>
                            <span class="text-two">Contact Us <i class="fa-solid fa-circle-plus"></i></span>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- cta-3 area end -->

    <!-- clients-testimonial-2 area start -->
    <section class="clients-testimonial-2 overflow-hidden relative section-space__top ">
        <div class="container">
            <div class="row mb-60 mb-md-100 mb-sm-100 mb-xs-80 justify-content-center align-items-center">
                <div class="col-lg-6">
                    <div class="section__title-wrapper mb-md-30 mb-sm-30 mb-xs-20">
                        <h5 class="section__subtitle title-glow mb-15 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Clients Testimonials</h5>
                        <h2 class="section__title color-theme-black mb-0 title-animation">Clients Success Stories</h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="clients-testimonial-2__slider__arrow d-flex justify-content-lg-end justify-content-start">
                        <button class="clients-testimonial-2__slider__arrow-prev d-flex align-items-center justify-content-center">
                            <i class="fa-solid fa-arrow-left"></i>
                        </button>

                        <button class="clients-testimonial-2__slider__arrow-next d-flex align-items-center justify-content-center">
                            <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="swiper clients-testimonial-2__active">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-1.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Leo Scott</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-2.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Fill Nathan</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-3.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Jonathan Blu</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-4.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Wade Warren</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-1.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Leo Scott</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-2.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Wade Warren</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-3.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Jonathan Blu</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="clients-testimonial-2__item">
                            <div class="clients-testimonial-2__icon">
                                <img src="./assets/imgs/clients-testimonial-2/quite.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-media">
                            <img src="./assets/imgs/clients-testimonial-2/author-3.png" alt="image not found">
                            </div>
                            <div class="clients-testimonial-2__item-content">
                                <p>Adipiscing elit, sed do emod tempor incididunt ut labored etos dolore magna aliquant. Ut enim ad minim veniam  nostrud exercitation ullamco</p>

                                <div class="clients-testimonial-2__author">
                                    <h4><a href="appoinment.html">Fill Nathan</a></h4>
                                    <span>The Walt Disney Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- clients-testimonial-2 area end -->

    <!-- specialist-doctor-2 area start -->
    <section class="specialist-doctor-2 section-space">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section__title-wrapper mb-60 mb-30">
                        <h5 class="section__subtitle title-glow mb-15 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Specialist Doctor</h5>
                        <h2 class="section__title color-theme-black font-medium mb-10 title-animation">Your Path to Emotional Well-Being</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-xl-4">
                    <div class="specialist-doctor-2__item position-relative overflow-hidden">
                        <div class="specialist-doctor-2__item-media wow clip-a-z">
                            <img src="./assets/imgs/specialist-doctor-2/specialist-doctor-1.png" class="img-fluid" alt="image not found">
                        </div>

                        <div class="specialist-doctor-2__item-content">
                            <div class="specialist-doctor-2__item-content-text text-center">
                                <h4 class="title-animation mb-10"><a href="doctor-details.html">Wade Warren</a></h4>
                                <p class="mb-0">Electrician</p>
                            </div>

                            <div class="specialist-doctor-2__item-content-share">
                                <a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="https://x.com/">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.52217 6.77686L15.4785 0.00195312H14.0671L8.89516 5.88451L4.76437 0.00195312H0L6.24656 8.89742L0 16.002H1.41155L6.87321 9.78977L11.2356 16.002H16L9.52183 6.77686H9.52217ZM7.58887 8.97579L6.95596 8.09L1.92015 1.04169H4.0882L8.15216 6.72991L8.78507 7.61569L14.0677 15.0095H11.8997L7.58887 8.97613V8.97579Z" fill="#071C3C"/>
                                    </svg>
                                </a>
                                <a href="https://bd.linkedin.com/"><i class="fa-brands fa-linkedin"></i></a>
                                <a href="https://www.pinterest.com/"><i class="fa-brands fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="specialist-doctor-2__item position-relative overflow-hidden">
                        <div class="specialist-doctor-2__item-media wow clip-a-z">
                            <img src="./assets/imgs/specialist-doctor-2/specialist-doctor-2.png" class="img-fluid" alt="image not found">
                        </div>

                        <div class="specialist-doctor-2__item-content">
                            <div class="specialist-doctor-2__item-content-text text-center">
                                <h4 class="title-animation mb-10"><a href="doctor-details.html">Darrell Steward</a></h4>
                                <p class="mb-0">Marketing Manager</p>
                            </div>

                            <div class="specialist-doctor-2__item-content-share">
                                <a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="https://x.com/">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.52217 6.77686L15.4785 0.00195312H14.0671L8.89516 5.88451L4.76437 0.00195312H0L6.24656 8.89742L0 16.002H1.41155L6.87321 9.78977L11.2356 16.002H16L9.52183 6.77686H9.52217ZM7.58887 8.97579L6.95596 8.09L1.92015 1.04169H4.0882L8.15216 6.72991L8.78507 7.61569L14.0677 15.0095H11.8997L7.58887 8.97613V8.97579Z" fill="#071C3C"/>
                                    </svg>
                                </a>
                                <a href="https://bd.linkedin.com/"><i class="fa-brands fa-linkedin"></i></a>
                                <a href="https://www.pinterest.com/"><i class="fa-brands fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="specialist-doctor-2__item position-relative overflow-hidden">
                        <div class="specialist-doctor-2__item-media wow clip-a-z">
                            <img src="./assets/imgs/specialist-doctor-2/specialist-doctor-3.png" class="img-fluid" alt="image not found">
                        </div>

                        <div class="specialist-doctor-2__item-content">
                            <div class="specialist-doctor-2__item-content-text text-center">
                                <h4 class="title-animation mb-10"><a href="doctor-details.html">Fill Nathan</a></h4>
                                <p class="mb-0">CEO</p>
                            </div>

                            <div class="specialist-doctor-2__item-content-share">
                                <a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="https://x.com/">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.52217 6.77686L15.4785 0.00195312H14.0671L8.89516 5.88451L4.76437 0.00195312H0L6.24656 8.89742L0 16.002H1.41155L6.87321 9.78977L11.2356 16.002H16L9.52183 6.77686H9.52217ZM7.58887 8.97579L6.95596 8.09L1.92015 1.04169H4.0882L8.15216 6.72991L8.78507 7.61569L14.0677 15.0095H11.8997L7.58887 8.97613V8.97579Z" fill="#071C3C"/>
                                    </svg>
                                </a>
                                <a href="https://bd.linkedin.com/"><i class="fa-brands fa-linkedin"></i></a>
                                <a href="https://www.pinterest.com/"><i class="fa-brands fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- specialist-doctor-2 area end -->

    <!-- appointment-4 area start -->
    <section class="appointment-4 ">
        <div class="container">
            <div class="appointment-4-top">
                <div class="container">
                    <div class="appointment-4-top__item-wrapper">
                        <div class="appointment-4-top__item">
                            <div class="appointment-4-top__item-content">
                                <div class="appointment-4-top__item-content-icon">
                                    <img src="./assets/imgs/appointment-4/appointment-1.png" alt="image not found">
                                </div>
                                <div class="appointment-4-top__item-content-text">
                                    <h2><span class="odometer" data-count="200">0</span>+</h2>
                                    <h6 class="title-animation">Happy patients</h6>
                                </div>
                            </div>
                        </div>

                        <div class="appointment-4-top__item">
                            <div class="appointment-4-top__item-content">
                                <div class="appointment-4-top__item-content-icon">
                                    <img src="./assets/imgs/appointment-4/appointment-2.png" alt="image not found">
                                </div>
                                <div class="appointment-4-top__item-content-text">
                                    <h2><span class="odometer" data-count="20">0</span>+</h2>
                                    <h6 class="title-animation">saved hearts</h6>
                                </div>
                            </div>
                        </div>

                        <div class="appointment-4-top__item">
                            <div class="appointment-4-top__item-content">
                                <div class="appointment-4-top__item-content-icon">
                                    <img src="./assets/imgs/appointment-4/appointment-3.png" alt="image not found">
                                </div>
                                <div class="appointment-4-top__item-content-text">
                                    <h2><span class="odometer" data-count="10">0</span>k+</h2>
                                    <h6 class="title-animation">expert doctors</h6>
                                </div>
                            </div>
                        </div>

                        <div class="appointment-4-top__item">
                            <div class="appointment-4-top__item-content">
                                <div class="appointment-4-top__item-content-icon">
                                    <img src="./assets/imgs/appointment-4/appointment-4.png" alt="image not found">
                                </div>
                                <div class="appointment-4-top__item-content-text">
                                    <h2><span class="odometer" data-count="900">0</span>+</h2>
                                    <h6 class="title-animation">serenity work</h6>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="appointment-4-bottom">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="appointment-4-bottom__content">
                            <div class="section__title-wrapper mb-30">
                                <h5 class="section__subtitle title-glow mb-15 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Appointment Now</h5>
                                <h2 class="section__title color-theme-black font-medium mb-10 title-animation">Get In Touch With Us</h2>
                                <p class="mb-0">They utilize evidence-based practices to foster personal growth, enhance coping strategies, and promote healthy relationships. By creating a safe and non-judgmental space, they empower</p>
                            </div>

                            <div class="appointment-4-bottom__wrapper">
                                <i class="fa-solid fa-phone"></i>
                                <div class="appointment-4-bottom__wrapper-text">
                                    <span>Call Us:</span>
                                    <h3><a href="tel:15550133">(+1) 555-0133</a></h3>
                                </div>
                            </div>

                            <ul>
                                <li><span>Monday - Friday</span></li>
                                <li>8.00 am - 7.00 pm / Sunday (Closed)</li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <form  class="appointment-4__form">
                            <h3 class=" text-white text-center title-animation mb-15">Make An Appointment</h3>
                            <div class="row">
                                <div class="col-12">
                                    <div class="appointment-4__form-input">
                                        <input name="name" id="name" type="text" placeholder="Your name">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="appointment-4__form-input">
                                        <input name="phone" id="phone" type="text" placeholder="Phone Number">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="appointment-4__form-select">
                                        <select name="doctor" id="doctor" style="display: none;">
                                            <option>Appoinment Subject</option>
                                            <option>Option-1</option>
                                            <option>Option-2</option>
                                            <option>Option-3</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="appointment-4__form-input">
                                        <textarea name="textarea" id="textarea" placeholder="Message here.."></textarea>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <button type="submit" class="rr-btn rr-btn__green mt-0">
                                        <span class="btn-wrap">
                                            <span class="text-one">Appointment now </span>
                                            <span class="text-two">Appointment now </span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- appointment-4 area end -->

<!-- special-offer area start -->
    <section class="special-offer section-space">
        <div class="container">
            <div class="row mb-60 mb-xs-50 align-items-end">
                <div class="col-lg-6">
                    <div class="section__title-wrapper">
                        <h5 class="section__subtitle title-glow mb-20 mb-xs-10 title-animation"><img src="assets/imgs/ask-quesiton/heart-3.png" alt="icon not found" class="img-fluid"> Special Offers</h5>
                        <h2 class="section__title color-theme-black font-medium mb-0 title-animation">Where Healing and Growth Intersect</h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <p class="mb-0">Lorem ipsum dolor Lorem ipsum dolor sit amet consectetur adipiscing elit platea on the pharetra, nostra mtis hendrerit proin mollis pretium facilisi in, ligula volutpat sit amet consectetur adipiscing elit platea on the pharetra, nostra mtis hendrerit </p>
                </div>
            </div>

            <div class="row mb-minus-27">
                <div class="col-xl-6">
                    <div class="special-offer__item special-offer__item-1">
                        <div class="special-offer__item-media wow clip-a-z">
                            <img src="./assets/imgs/special-offer/special-offer-1.jpg" alt="image not found">
                        </div>
                        <div class="special-offer__item-content">
                            <h3><a href="blog-details.html">Empowering You to Overcome, Thrive, and Flourish</a></h3>
                            <p class="mb-0">These disciplines focus on improving mental health and well-being by providing support and guidance through various therapeutic techniques. Counselors and psychologists work with clients to address</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="special-offer__item align-items-center">
                        <div class="special-offer__item-media wow clip-a-z">
                            <img src="./assets/imgs/special-offer/special-offer-2.jpg" alt="image not found">
                        </div>
                        <div class="special-offer__item-content">
                            <h4><a href="blog-details.html">Transforming Mental Health with Compassionate Care</a></h4>
                            <p class="mb-0">These disciplines focus on improving mental health and well-being by providing support and guidance through</p>
                        </div>
                    </div>
                    <div class="special-offer__item align-items-center">
                        <div class="special-offer__item-media wow clip-a-z">
                            <img src="./assets/imgs/special-offer/special-offer-3.jpg" alt="image not found">
                        </div>
                        <div class="special-offer__item-content">
                            <h4><a href="blog-details.html">Guiding You from Darkness to Light with Expert Therapy</a></h4>
                            <p class="mb-0">These disciplines focus on improving mental health and well-being by providing support and guidance through</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- special-offer area end -->
</main>
<!-- Body main wrapper end -->

<footer>
    <section class="footer-4__area-common white-bg overflow-hidden">
        <div class="container">
            <div class="row mb-minus-50">
                <div class="col-lg-3 col-6">
                    <div class="footer-4__widget footer-4__widget-item-1">
                        <div class="footer-4__logo mb-20">
                            <a href="index.html">
                                <img class="img-fluid" src="assets/imgs/logo/footer-logo-4.svg" alt="logo not found">
                            </a>
                        </div>

                        <div class="footer-4__content">
                            <p class="mb-0">Where Every Step Forward is a Step Towards Healing</p>
                        </div>

                        <div class="footer-4__social mt-30 mt-xs-30">
                            <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://www.pinterest.com/"><i class="fa-brands fa-pinterest-p"></i></a>
                            <a href="https://www.linkedin.com/"><i class="fa-brands fa-linkedin"></i></a>
                            <a href="https://twitter.com/">
                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.0596 6.77295L15.8879 -0.00195312H14.5068L9.44607 5.8806L5.40411 -0.00195312H0.742188L6.85442 8.89352L0.742188 15.998H2.12338L7.4676 9.78587L11.7362 15.998H16.3981L10.0593 6.77295H10.0596ZM8.16787 8.97189L7.54857 8.0861L2.62104 1.03779H4.74248L8.71905 6.726L9.33834 7.61179L14.5074 15.0056H12.386L8.16787 8.97223V8.97189Z" fill="#071C3C"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-6">
                    <div class="footer-4__widget footer-4__widget-item-2">
                        <div class="footer-4__widget-title">
                            <h4>Services</h4>
                        </div>
                        <div class="footer-4__link">
                            <ul>
                                <li><a href="about-us.html">Nurturing Minds</a></li>
                                <li><a href="about-us.html">Inspiring Hope</a></li>
                                <li><a href="about-us.html">Creating Change</a></li>
                                <li><a href="about-us.html">Mental Wellness</a></li>
                                <li><a href="about-us.html">Emotional Freedom</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-6">
                    <div class="footer-4__widget footer-4__widget-item-4">
                        <div class="footer-4__widget-title">
                            <h4>Recent Post</h4>
                        </div>

                        <div class="footer-4__post  mt-20 mt-xs-25">
                            <ul>
                                <li>
                                    <a href="blog-details.html">Your J ourney Wholeness Starts Here</a>
                                    <a href="blog-details.html"><i class="fa-solid fa-calendar-days"></i>October 19, 2022</a>
                                </li>
                                <li>
                                    <a href="blog-details.html">Comprehensive Care for Lifelong Mental</a>
                                    <a href="blog-details.html"><i class="fa-solid fa-calendar-days"></i>October 19, 2022</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="footer-4__widget footer-4__widget-item-5">
                        <div class="footer-4__widget-title">
                            <h4>Contact</h4>
                        </div>

                        <div class="footer-4__contact">
                            <ul>
                                <li>
                                    <span><i class="fa-solid fa-location-dot"></i>Address </span>
                                    <a href="https://maps.app.goo.gl/4XYAPDmpesGnSbsC8"> 8502 Preston Rd. Inglewood, Maine 98380</a>
                                </li>
                                <li>
                                    <span><i class="fa-solid fa-envelope"></i>Email </span>
                                    <a href="mailto:tim.jennings@example.com"> tim.jennings@example.com</a>
                                </li>
                                <li>
                                    <span><i class="fa-sharp fa-solid fa-phone"></i>Phone </span>
                                    <a href="tel:7025550122"> (702) 555-0122</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-4__cta-wrapper">
                <div class="footer-4__cta__content">
                    <h2>Subscribe Our newsletter</h2>
                </div>
                <div class="footer-4__cta__subscribe">
                    <div class="footer-4__cta__input-wapper">
                        <input type="text" placeholder="Enter Your Email">
                        <i class="fa-solid fa-envelope"></i>
                    </div>
                    <button type="submit" class="rr-btn btn-hover-white">
                        <span class="btn-wrap">
                            <span class="text-one">Subscribe Now</span>
                            <span class="text-two">Subscribe Now</span>
                        </span>
                    </button>
                </div>
            </div>
        </div>

        <div class="footer-4__bottom-wrapper">
            <div class="container">
                <div class="footer-4__bottom">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="footer-4__copyright text-lg-start text-center">
                                <p class="mb-0">© <a href="index.html">Medilix</a>  2024 | All Rights Reserved</p>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="footer-4__copyright-menu">
                                <ul>
                                    <li><a href="about-us.html">Trams & Condition</a></li>
                                    <li><a href="about-us.html">Privacy Policy</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</footer>
<!-- Footer area end -->

<!-- JS here -->
<script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
<script src="assets/js/plugins/waypoints.min.js"></script>
<script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
<script src="assets/js/plugins/meanmenu.min.js"></script>
<script src="assets/js/plugins/odometer.min.js"></script>
<script src="assets/js/plugins/swiper.min.js"></script>
<script src="assets/js/plugins/wow.js"></script>
<script src="assets/js/vendor/magnific-popup.min.js"></script>
<script src="assets/js/vendor/type.js"></script>
<script src="assets/js/plugins/nice-select.min.js"></script>
<script src="assets/js/vendor/jquery-ui.min.js"></script>
<script src="assets/js/vendor/jquery.appear.js"></script>
<script src="assets/js/plugins/parallax.min.js"></script>
<script src="assets/js/plugins/parallax-scroll.js"></script>
<script src="assets/js/plugins/gsap.min.js"></script>
<script src="assets/js/plugins/ScrollTrigger.min.js"></script>
<script src="assets/js/plugins/SplitText.js"></script>
<script src="assets/js/plugins/tween-max.min.js"></script>
<script src="assets/js/plugins/draggable.min.js"></script>
<script src="assets/js/plugins/smoothscroll.js"></script>
<script src="assets/js/vendor/ajax-form.js"></script>
<script src="assets/js/main.js"></script>
</body>

</html>
